import * as express from 'express';
const router = express.Router();
import signupController from '../controllers/user/Signup';
import loginController from '../controllers/user/Login';
import logoutController from '../controllers/user/logout';
import { validationCheck } from '../controllers/user/validationCheck';

import { updateTables } from '../controllers/tables/update';
import { deleteTables } from '../controllers/tables/delete';

import mypageController from '../controllers/pages/mypage';
import mainpageController from '../controllers/pages/mainpage';

import writeLetterController from '../controllers/template/writeLetter';
import readLetterController from '../controllers/template/readLetter';

router.post('/signup', signupController);
router.post('/login', loginController);
router.post('/logout',logoutController);
router.post('/nickcheck', validationCheck.nickname);
router.post('/delpassword', validationCheck.delMyAccPassword);

router.patch('/updateuser/:userId', updateTables.userUpdate);
router.patch('/updatetemplate/:templateId', updateTables.templateUpdate);
router.delete('/deleteuser/:userId', deleteTables.userDelete);
router.delete('/deletetemplate/:templateId', deleteTables.templateDelete);

router.get('/mypage', mypageController);
router.get('/mainpage', mainpageController);

router.post('/writeletter', writeLetterController);
router.get('/readletter/:templateId', readLetterController);

export default router;